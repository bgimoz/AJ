(function(){
const rm=()=>document.documentElement.classList.remove('aj-restore');
setTimeout(rm,5000);
/* guardar a vista do painel onde a pessoa está */
const sw=window.switchAdminView;window.switchAdminView=function(n,el){AJ_UI_SET('sub',n);return sw(n,el)};
/* depois de atualizar a página, volta ao sítio onde estava */
if(window.AJ_LIVE&&AJ_UI_GET('area')&&!/access_token=|type=/.test(location.hash)){
 AJ_SB.auth.getSession().then(async({data})=>{try{if(data.session)await AJ_ENTER(data.session.user);else AJ_UI_SET('area','')}catch(e){}finally{rm()}});
}else rm();
/* clicar no logótipo volta ao início */
const home=()=>{if(!/(^|\/)(index\.html)?$/.test(location.pathname)){location.href='index.html';return}const s=document.getElementById('siteView');history.replaceState(null,'',location.pathname);if(s.style.display==='none')showSite();else scrollTo({top:0,behavior:'smooth'})};
const link=(el,fn)=>{if(!el)return;el.style.cursor='pointer';el.setAttribute('role','link');el.setAttribute('tabindex','0');el.setAttribute('aria-label','AJ Serviços LDA — início');el.addEventListener('click',fn);el.addEventListener('keydown',e=>{if(e.key=='Enter'||e.key==' '){e.preventDefault();fn()}})};
link(document.querySelector('header .brand'),home);
document.querySelectorAll('.au-logo,#clientView .lg-brand').forEach(e=>link(e,home));
link(document.querySelector('#adminView .sb-brand'),()=>switchAdminView('processos',document.getElementById('sbnav-processos')));
})();
