window.AJ_CONFIG={supabaseUrl:"https://uszyeemainunopbrmwur.supabase.co",supabaseAnonKey:"sb_publishable_OBoPUCxUCszAiOT72kTluw_uboEX3fI"}; // <- cole aqui o URL e a anon key do Supabase
