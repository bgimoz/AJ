/* ux.js — menu mobile, tema, barra inferior, validação do formulário, abas do painel */
(function(){
const $=s=>document.querySelector(s),H=document.documentElement;
const svg=p=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
const MOON='<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',SUN='<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',MENU='<path d="M4 7h16M4 12h16M4 17h16"/>';

/* ---- tema: claro / escuro / automático, guardado ---- */
let mode='auto';try{mode=localStorage.getItem('aj_theme')||'auto'}catch(e){}
const mq=matchMedia('(prefers-color-scheme: dark)');
function apply(){const d=mode=='dark'||(mode=='auto'&&mq.matches);H.setAttribute('data-theme',d?'dark':'light');
 const m=$('meta[name=theme-color]');if(m)m.content=d?'#081318':'#0B2630';
 document.querySelectorAll('.seg button').forEach(b=>b.classList.toggle('on',b.dataset.t==mode))}
function setMode(m){mode=m;try{localStorage.setItem('aj_theme',m)}catch(e){}apply()}
if(mq.addEventListener)mq.addEventListener('change',apply);

/* ---- cabeçalho: tema + menu ---- */
$('.nav-right').insertAdjacentHTML('beforeend',`<button class="hbtn" id="themeBtn" aria-label="Alternar tema claro/escuro"><span class="m">${svg(MOON)}</span><span class="s">${svg(SUN)}</span></button><button class="hbtn" id="menuBtn" aria-label="Abrir menu" aria-expanded="false" aria-controls="navSheet">${svg(MENU)}</button>`);
$('#themeBtn').onclick=()=>setMode(H.getAttribute('data-theme')=='dark'?'light':'dark');

/* ---- menu em folha (telemóvel) ---- */
const L=[['index.html','Início'],['servicos.html','Serviços'],['como-funciona.html','Como funciona'],['portal.html','Portal do cliente'],['contacto.html','Contacto e cotação']];
document.body.insertAdjacentHTML('beforeend',`<div id="navSheet" aria-hidden="true"><div class="sh"></div><div class="bx" role="dialog" aria-modal="true" aria-label="Menu"><div class="sh-top"><b>Menu</b><button class="hbtn" id="shX" aria-label="Fechar menu">×</button></div>${L.map(([h,t])=>`<a class="l" href="${h}">${t}<span aria-hidden="true">›</span></a>`).join('')}<div class="seg" role="group" aria-label="Aparência"><button data-t="auto">Automático</button><button data-t="light">Claro</button><button data-t="dark">Escuro</button></div><button class="btn btn-solid btn-round" id="shLogin" data-auth="out">Entrar ou criar conta</button><button class="btn btn-solid btn-round" id="shArea" data-auth="in">A minha área</button></div></div>`);
const sh=$('#navSheet'),mb=$('#menuBtn');
const open=v=>{sh.classList.toggle('on',v);sh.setAttribute('aria-hidden',String(!v));mb.setAttribute('aria-expanded',String(v));document.body.style.overflow=v?'hidden':'';(v?$('#shX'):mb).focus({preventScroll:true})};
mb.onclick=()=>open(true);$('#shX').onclick=()=>open(false);sh.querySelector('.sh').onclick=()=>open(false);
sh.addEventListener('click',e=>{if(e.target.closest('a.l'))open(false)});
sh.querySelectorAll('.seg button').forEach(b=>b.onclick=()=>setMode(b.dataset.t));
['shLogin','shArea'].forEach(i=>document.getElementById(i).onclick=()=>{open(false);AJ_OPEN('login')});
document.addEventListener('keydown',e=>{if(e.key=='Escape'&&sh.classList.contains('on'))open(false)});
apply();

/* ---- barra inferior fixa (telemóvel): Menu · Pedir cotação · WhatsApp ---- */
const wf=$('.wa-float');
$('#siteView').insertAdjacentHTML('beforeend',`<div id="mBar" class="print-hide"><button class="btn btn-glass btn-round" id="mMenu" type="button">Menu</button><a class="btn btn-solid btn-round" href="contacto.html">Pedir cotação</a><a class="wa" href="${wf.href}" target="_blank" rel="noopener" aria-label="Falar por WhatsApp">${wf.innerHTML}</a></div>`);
$('#mMenu').onclick=()=>open(true);
$('#mBar .wa').addEventListener('click',function(){this.href=wf.href});
document.addEventListener('focusin',e=>{if(e.target.matches('input,textarea,select'))document.body.classList.add('kb')});
document.addEventListener('focusout',()=>document.body.classList.remove('kb'));

/* ---- secção atual destacada no menu do computador ---- */
const cur=location.pathname.split('/').pop()||'index.html';document.querySelectorAll('.navlinks a,#navSheet a.l').forEach(a=>{if(a.getAttribute('href')==cur){a.classList.add('on');a.setAttribute('aria-current','page')}});

/* ---- perguntas frequentes acessíveis (teclado + leitores de ecrã) ---- */
document.querySelectorAll('.faq-q').forEach(q=>{const it=q.parentElement;q.setAttribute('role','button');q.tabIndex=0;q.setAttribute('aria-expanded','false');
 q.addEventListener('keydown',e=>{if(e.key=='Enter'||e.key==' '){e.preventDefault();q.click()}});
 new MutationObserver(()=>q.setAttribute('aria-expanded',String(it.classList.contains('open')))).observe(it,{attributes:true,attributeFilter:['class']})});

/* ---- formulário de cotação: validação com mensagens e Enter = Continuar ---- */
function need(id,ok,msg){const el=document.getElementById(id);let e=el.parentElement.querySelector('.fe');
 if(!e){e=document.createElement('div');e.className='fe';e.setAttribute('role','alert');el.parentElement.appendChild(e)}
 const bad=!ok(el.value.trim());el.setAttribute('aria-invalid',String(bad));e.textContent=bad?msg:'';return!bad}
const base=window.nextStep;
window.nextStep=function(n){
 const r=n==1?[need('nome',v=>v.length>1,'Escreva o seu nome ou o da empresa.'),need('tel',v=>v.replace(/\D/g,'').length>=7,'Escreva um número válido (mínimo 7 dígitos).')]
  :[need('carga',v=>!!v,'Escolha o tipo de carga.'),need('rota2',v=>!!v,'Escolha a rota.')];
 if(r.every(Boolean)){base(n);$('#quoteForm').scrollIntoView({block:'center',behavior:'smooth'})}};
if($('#quoteForm'))$('#quoteForm').addEventListener('keydown',e=>{if(e.key!='Enter'||e.target.tagName=='TEXTAREA')return;e.preventDefault();
 const s=$('.form-step.active');if(s&&s.id!='formStep3'){const b=s.querySelector('.btn-solid');if(b)b.click()}});

/* ---- painel interno: barra de abas no telemóvel ---- */
const K=[['processos','Processos'],['clientes','Clientes'],['documentos','Documentos'],['relatorios','Relatórios'],['definicoes','Definições'],['admin','Admin']];
const tb=document.createElement('nav');tb.id='aTabs';tb.setAttribute('aria-label','Secções do painel');
tb.innerHTML=K.map(([k,t])=>{const i=document.querySelector('#sbnav-'+k+' svg');return`<button type="button" data-k="${k}">${i?i.outerHTML:''}<span>${t}</span></button>`}).join('');
$('#adminView').appendChild(tb);
tb.addEventListener('click',e=>{const b=e.target.closest('button');if(b)switchAdminView(b.dataset.k,document.getElementById('sbnav-'+b.dataset.k))});
function sync(){const on=document.querySelector('#adminView .sb-item.active'),a=document.getElementById('sbnav-admin');
 tb.querySelectorAll('button').forEach(b=>b.classList.toggle('on',!!on&&on.id=='sbnav-'+b.dataset.k));
 tb.querySelector('[data-k=admin]').style.display=a&&a.style.display!='none'?'':'none'}
const sw=window.switchAdminView;window.switchAdminView=function(n,el){const r=sw(n,el);sync();return r};
document.addEventListener('aj:login',()=>setTimeout(sync,50));

/* ---- fluidez e orientação ---- */
const up=document.createElement('button');up.id='toTop';up.setAttribute('aria-label','Voltar ao topo');up.innerHTML=svg('<path d="M12 19V5M5 12l7-7 7 7"/>');document.body.appendChild(up);
up.onclick=()=>scrollTo({top:0,behavior:'smooth'});
addEventListener('scroll',()=>up.classList.toggle('on',scrollY>900&&$('#siteView').style.display!=='none'),{passive:true});
const pf=new Set(),pre=e=>{const a=e.target.closest&&e.target.closest('a[href*=".html"]');if(!a)return;const h=a.getAttribute('href').split('#')[0];if(/^(http|mailto|tel)/.test(h)||pf.has(h))return;pf.add(h);const l=document.createElement('link');l.rel='prefetch';l.href=h;document.head.appendChild(l)};
document.addEventListener('pointerover',pre);document.addEventListener('touchstart',pre,{passive:true});
document.querySelectorAll('[data-q]').forEach(a=>a.addEventListener('click',()=>{const k=a.dataset.q,w=AJ_CONTACTS.whatsapp[0];a.href=k=='wa'?'https://wa.me/'+w:k=='tel'?'tel:+'+w:'mailto:'+AJ_CONTACTS.emails[0]}));
const qp=new URLSearchParams(location.search).get('conta');if(qp&&window.AJ_OPEN)setTimeout(()=>AJ_OPEN(qp),150);
})();
