const stepLabels = { 1:'Passo 1 de 3 — Os seus dados', 2:'Passo 2 de 3 — A sua carga', 3:'Passo 3 de 3 — Detalhes' };
  function goToStep(n){
    document.querySelectorAll('.form-step').forEach(s => s.classList.remove('active'));
    document.getElementById('formStep' + n).classList.add('active');
    [1,2,3].forEach(i => document.getElementById('dot'+i).classList.toggle('active', i <= n));
    const label = document.getElementById('stepLabel');
    if(label) label.textContent = stepLabels[n];
  }
  function nextStep(from){ goToStep(from + 1); }
  function prevStep(from){ goToStep(from - 1); }
  const AJ_CONTACTS = {
    whatsapp: ['258865686897', '258870102070', '258861668327'],
    emails: ['ajaduaneira@gmail.com', 'marcosap638@gmail.com', 'jeronimohoracio84@gmail.com']
  };
  function submitQuote(){
    const nome = (document.getElementById('nome').value || 'Não indicado').trim();
    const tel = (document.getElementById('tel').value || 'Não indicado').trim();
    const carga = document.getElementById('carga').value || 'Não indicado';
    const rota = document.getElementById('rota2').value || 'Não indicado';
    const msg = (document.getElementById('msg').value || 'Sem informação adicional').trim();

    const corpo =
      `Novo pedido de cotação — site AJ Aduaneira\n\n` +
      `Nome/Empresa: ${nome}\n` +
      `Contacto: ${tel}\n` +
      `Tipo de carga: ${carga}\n` +
      `Origem -> Destino: ${rota}\n` +
      `Detalhes adicionais: ${msg}`;

    const assunto = `Pedido de cotação — ${nome}`;
    const mailtoLink = `mailto:${AJ_CONTACTS.emails.join(',')}?subject=${encodeURIComponent(assunto)}&body=${encodeURIComponent(corpo)}`;
    const waText = encodeURIComponent(corpo);
    AJ_CONTACTS.whatsapp.forEach((num, i) => {
      const btn = document.getElementById('waBtn' + (i + 1));
      if (btn) btn.href = `https://wa.me/${num}?text=${waText}`;
    });

    document.querySelectorAll('.form-step').forEach(s => s.classList.remove('active'));
    document.getElementById('formStepDone').classList.add('active');

    // Abre o cliente de email do utilizador já com a mensagem pronta,
    // endereçada aos 3 contactos. Não existe forma de enviar WhatsApp
    // automaticamente para vários números sem ação do utilizador — por
    // isso ficam também os 3 botões de WhatsApp prontos a usar acima.
    const mb = document.getElementById('mailBtn'); if(mb) mb.href = mailtoLink;
  }
  function resetForm(){
    document.getElementById('quoteForm').reset();
    goToStep(1);
  }

  // sticky CTA bar
  const ctaBar = document.getElementById('ctaBar');
  const heroSection = document.querySelector('.hero');
  const contactSection = document.getElementById('contacto');
  const siteHeader = document.querySelector('header');
  let lastY = window.scrollY;
  window.addEventListener('scroll', () => {
    const y = window.scrollY, down = y > lastY + 4, up = y < lastY - 4;
    const past = y > (heroSection ? heroSection.offsetHeight : 300);
    const nearContact = (contactSection ? contactSection.getBoundingClientRect().top < 120 : false);
    if (!past || nearContact) { ctaBar.classList.remove('show'); siteHeader.classList.remove('hide'); }
    else if (down) { ctaBar.classList.add('show'); siteHeader.classList.add('hide'); }
    else if (up) { ctaBar.classList.remove('show'); siteHeader.classList.remove('hide'); }
    if (down || up) lastY = y;
  }, { passive: true });

  const ADMIN_VIEWS = {
    processos:  { title:'Processos',  sub:'9 activos · actualizado agora mesmo' },
    clientes:   { title:'Clientes',   sub:'9 clientes na base de dados' },
    documentos: { title:'Documentos', sub:'6 documentos associados a processos activos' },
    relatorios: { title:'Relatórios', sub:'Resumo do mês em curso' },
    definicoes: { title:'Definições', sub:'Perfil da empresa e preferências de notificação' },
  };
  function switchAdminView(name, el){
    Object.keys(ADMIN_VIEWS).forEach(k => {
      const v = document.getElementById('view-' + k);
      if (v) v.style.display = (k === name) ? 'block' : 'none';
    });
    document.querySelectorAll('#adminView .sb-item').forEach(i => i.classList.remove('active'));
    if (el) el.classList.add('active');
    const info = ADMIN_VIEWS[name];
    if (info) {
      document.getElementById('topbarTitle').textContent = info.title;
      document.getElementById('topbarSub').textContent = info.sub;
    }
  }
  function showAdmin(){
    document.getElementById('siteView').style.display = 'none';
    document.getElementById('adminView').style.display = 'block';
    switchAdminView('processos', document.getElementById('sbnav-processos'));
    window.scrollTo(0,0);
  }
  function showSite(){
    document.getElementById('adminView').style.display = 'none';
    document.getElementById('siteView').style.display = 'block';
    window.scrollTo(0,0);
  }

  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.15 });
  document.querySelectorAll('.reveal').forEach(el => io.observe(el));

  document.querySelectorAll('.faq-item').forEach(item => {
    item.querySelector('.faq-q').addEventListener('click', () => {
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item.open').forEach(o => o.classList.remove('open'));
      if(!isOpen) item.classList.add('open');
    });
  });

  

  const counters = document.querySelectorAll('.count');
  const counterIO = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        counters.forEach(el => {
          const target = parseInt(el.dataset.target, 10);
          const prefix = el.dataset.prefix || ''; const suffix = el.dataset.suffix || '';
          const duration = 1200; const start = performance.now();
          function tick(now){
            const p = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - p, 3);
            el.textContent = prefix + Math.round(eased * target) + suffix;
            if(p < 1) requestAnimationFrame(tick);
          }
          requestAnimationFrame(tick);
        });
        counterIO.disconnect();
      }
    });
  }, { threshold: 0.4 });
  const trustStrip = document.querySelector('.trust-strip');
  if(trustStrip) counterIO.observe(trustStrip);

  const routeWrap = document.getElementById('routeWrap');
  const routeIO = new IntersectionObserver((entries) => {
    entries.forEach(e => { if(e.isIntersecting){ routeWrap.classList.add('in'); routeIO.unobserve(routeWrap); } });
  }, { threshold: 0.3 });
  if(routeWrap) routeIO.observe(routeWrap);

  const portalStates = [
    { cls:'pending', text:'Doc. pendente' }, { cls:'progress', text:'Em alfândega' },
    { cls:'progress', text:'Em trânsito' }, { cls:'done', text:'Concluído' }
  ];
  const dataRows = document.querySelectorAll('#portalTable .portal-table-row:not(.head)');
  setInterval(() => {
    if(!dataRows.length||document.hidden||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
    const row = dataRows[Math.floor(Math.random() * dataRows.length)];
    const tag = row.querySelector('.tag');
    const next = portalStates[Math.floor(Math.random() * portalStates.length)];
    tag.className = 'tag ' + next.cls;
    tag.textContent = next.text;
  }, 2600);

  document.querySelectorAll('[data-tilt]').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform = `rotateX(${(-y*10).toFixed(2)}deg) rotateY(${(x*10).toFixed(2)}deg) translateY(-4px)`;
    });
    card.addEventListener('mouseleave', () => { card.style.transform = 'rotateX(0) rotateY(0) translateY(0)'; });
  });
